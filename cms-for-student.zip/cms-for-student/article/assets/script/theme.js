$(document).ready(function() {
    $('.main-slide-banner').slick({
        speed: 2000,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
    });
});