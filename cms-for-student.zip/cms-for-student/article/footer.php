    <footer>
        <div class="container">
            <div class="logo">
                <a href="">
                    <img src="https://dummyimage.com/120" alt="">
                </a>
            </div>
            <div class="about">
                <div class="description">
                    Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.
                </div>
            </div>
            <div class="connect">
                <ul>
                    <li>
                        <a href=""><img src="https://dummyimage.com/40/27306D" alt=""></a>
                    </li>
                    <li>
                        <a href=""><img src="https://dummyimage.com/40/27306D" alt=""></a>
                    </li>
                    <li>
                        <a href=""><img src="https://dummyimage.com/40/27306D" alt=""></a>
                    </li>
                </ul>
            </div>
        </div>
    </footer> 
</body>
<!-- @slick slider -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<!-- @theme js -->
<script src="assets/script/theme.js"></script>
<!-- @funcy box -->
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>